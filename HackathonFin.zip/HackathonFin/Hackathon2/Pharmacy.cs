﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hackathon2
{
    public class Pharmacy : Building
    {

        public string salesAmt { get; set; }
        

        public Pharmacy(string Name, string Address, string Eircode, string Coordinatex, string Coordinatey, string salesAmt) : base(Name, Address, Eircode, Coordinatex, Coordinatey)
        {
            this.salesAmt = salesAmt;      
        }

        public override void SearchByEircode()
        {
            
        }

        public override void ShowDetails()
        {
            
        }

    }
}
